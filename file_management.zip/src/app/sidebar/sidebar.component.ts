import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../data.service';
import { Router } from '@angular/router';

export interface Folder {
  id: string;
  name: string;
  parentId: string | null;
  children: Folder[];
  selected: boolean;
  visible: boolean;
  files: any[];
}

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  folders: Folder[] = [];
  showFolderModal:boolean = false;
  newFolderName = '';
  showFolderList:boolean = false;
  selectedFolderFiles: any[] = [];
  selectedFolder: Folder | null = null; 
  selectedFileContent: string | null = null;
  showcontent:boolean = false;
  selectedSubfolder: Folder | null = null;


  @ViewChild('uploadFileInput') uploadFileInput!: ElementRef<HTMLInputElement>;

  projectForm = new FormGroup({
    newFolderName: new FormControl('', Validators.required),
  });

  constructor(public service: DataService, private router: Router) {
    this.folder();
  }

  ngOnInit(): void {}

  openFolderModal() {
    this.showFolderModal = true;
  }

  closeFolderModal() {
    this.showFolderModal = false;
    this.newFolderName = '';
  }

  addFolder(): void {
    const folderName = this.projectForm.get('newFolderName')?.value;
    if (folderName) {
      const parentId = this.selectedFolder ? this.selectedFolder.id : null;
      this.service.addFolder(folderName, parentId).subscribe(response => {
        console.log("Folder added", response);
        this.refreshData(); 
      }, error => {
        console.log("Folder not added");
      });
    }
    this.projectForm.reset();
    this.closeFolderModal();
  }

  togglePopup(): void {
    this.showFolderModal = !this.showFolderModal;
  }


  folder() {
    this.service.getFolders().subscribe(
      folders => {
        this.folders = this.generateHierarchy(folders);
        console.log(this.folders);
      },
      error => {
      }
    );
  }

  toggleFolderList(): void {
    this.showFolderList = !this.showFolderList;
  }
  toggleFolderVisibility(folder: Folder): void {
    folder.visible = !folder.visible;
  }
  loadFolders(): void {
    this.service.getFolders().subscribe(folders => {
      this.folders = folders;
    });
  }

  selectFolder(folder: Folder): void {
    if (folder === this.selectedFolder) {
      this.selectedFolder = null;
      this.selectedFolderFiles = [];
    } else {
      this.selectedFolder = folder;
      this.service.getFilesByFolderId(folder.id).subscribe(files => {
        this.selectedFolderFiles = files;
      });
    }
  }
  selectSubfolder(subfolder: Folder): void {
    if (this.selectedFolder) {
      this.selectedFolder.selected = false;
    }
  
    if (subfolder.children.length === 0) {
      this.selectedFolderFiles = [];
    } else {
      this.service.getFilesByFolderId(subfolder.id).subscribe(files => {
        this.selectedFolderFiles = files;
      });
    }
  
    this.selectedSubfolder = subfolder;
    this.loadSubfolderContent(subfolder);
  }
  
  
  private loadSubfolderContent(folder: Folder): void {
    this.service.getFilesByFolderId(folder.id).subscribe(files => {
      this.selectedFolderFiles = files;
    });
  
    for (const subfolder of folder.children) {
      this.loadSubfolderContent(subfolder);
    }
  }
  
  

  uploadFile(event: any): void {
    const selectedFile = event.target.files[0];
    if (selectedFile && this.selectedSubfolder) {
      this.service.uploadFileToFolder(selectedFile, this.selectedSubfolder.id)
        .subscribe(response => {
          console.log('File and folder info sent:', response);
        },
        error => {
          console.error('Error sending file and folder info:', error);
        });
  
      event.target.value = null;
    } else if (!this.selectedSubfolder) {
      console.log('Please select a subfolder first.');
    } else {
      console.log('Please select a file to send.');
    }
  }
  

  refreshData(): void {
    if (this.selectedFolder) {
      const selectedFolderId = this.selectedFolder.id;
      this.service.getFilesByFolderId(selectedFolderId).subscribe(files => {
        this.selectedFolderFiles = files;
       // console.log(this.selectedFolderFiles );
      });
    } else {
      this.selectedFolder = null;
      this.selectedFolderFiles = [];
    }
    this.service.getFolders().subscribe(data => {
      this.folders = this.generateHierarchy(data);
    });
  }

  closeFile() {
    this.selectedFileContent = null;
    this.showcontent=false;
  }

  private generateHierarchy(flatFolders: Folder[]): Folder[] {
    const folderMap = new Map<string, Folder>();
    const rootFolders: Folder[] = [];

    for (const flatFolder of flatFolders) {
      const folder: Folder = {
        ...flatFolder,
        children: [],
        visible: false, 
        files: [] 
      };
      folderMap.set(folder.id, folder);
    }

    for (const flatFolder of flatFolders) {
      const folder = folderMap.get(flatFolder.id);
      if (folder && flatFolder.parentId) {
        const parent = folderMap.get(flatFolder.parentId);
        if (parent) {
          parent.children.push(folder);
        }
      } else if (!flatFolder.parentId) {
        if (folder) {
          rootFolders.push(folder);
        }
      }
    }

    return rootFolders;
  }
}
