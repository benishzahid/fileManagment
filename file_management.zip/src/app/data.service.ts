import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  //private folders: any[] = [];
  //private uploadedFiles: any[] = [];
 // selectedFolder: any;
 selectedFileContent: string | null = null;
  selectedFileMimeType: string | null = null;
  constructor(private http: HttpClient) { }

  addFolder(folderName: string, parentId: string | null): Observable<any> {
    const body = { name: folderName, parentId: parentId };
    return this.http.post(`http://localhost:3000/folder`, body);
  }

  getFolders(): Observable<any[]> {
    return this.http.get<any[]>('http://localhost:3000/folder');
  }
  uploadFileToFolder(file: File, folderId: any): Observable<any> {
    const reader = new FileReader();
    
    return new Observable(observer => {
      reader.onload = (event: any) => {
        const fileContentBase64 = event.target.result.split(',')[1]; // Extract Base64 content
        const uploadedFile = {
          fileName: file.name,
          folderId: folderId,
          fileContent: fileContentBase64
        };

        this.http.post('http://localhost:3000/upload', uploadedFile).subscribe(
          response => {
            console.log('File content sent to server:', response);
            observer.next(response);
            observer.complete();
          },
          error => {
            console.error('Error sending file content:', error);
            observer.error(error);
          }
        );
      };

      reader.readAsDataURL(file); 
    });
  }

  getFilesByFolderId(folderId: any): Observable<any[]> {
    const url = `${`http://localhost:3000/upload`}?folderId=${folderId}`;

    return this.http.get<any[]>(url);  }
    getFiles(): Observable<any[]> {
  
      return this.http.get<any[]>('http://localhost:3000/upload');  }
  
}
